import { useMemo, useState, type ReactNode, type ButtonHTMLAttributes, type InputHTMLAttributes, type SelectHTMLAttributes, type TextareaHTMLAttributes } from 'react'

type Auth = 'welcome' | 'login' | 'signup' | 'app'
type Tab = 'overview' | 'list' | 'settings'
type View = { name: 'overview' } | { name: 'list' } | { name: 'settings' } | { name: 'new' } | { name: 'case'; id: string } | { name: 'message'; id: string }
type Status = 'Open' | 'Awaiting response' | 'Resolved' | 'Rejected'
type Evidence = { receipt: boolean; photo: boolean; po: boolean; notes: boolean }
type Case = {
  id: string; supplier: string; branch: string; po: string; date: string; item: string; unitPrice: number
  ordered: number; received: number; type: string; notes: string; status: Status; evidence: Evidence
  files: { name: string; size: string }[]; timeline: { at: string; text: string }[]; recovered: number
}

const mark = '/assets/37574.svg'
const SUPPLIERS = ['Northline Food Supplies', 'FreshRoute Distributors', 'Island Dairy Co.', 'Metro Dry Goods']
const BRANCHES = ['Manila Branch', 'Makati Branch', 'Quezon City Branch']
const ISSUES = ['Short delivery', 'Damaged items', 'Wrong item', 'Billing mismatch', 'Expired / spoiled']
const STATUSES: Status[] = ['Open', 'Awaiting response', 'Resolved', 'Rejected']
const peso = (n: number) => '₱' + n.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
const today = () => new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
const value = (c: Case) => Math.max(0, c.ordered - c.received) * c.unitPrice
const ready = (e: Evidence) => Object.values(e).every(Boolean)

const SEED: Case[] = [
  { id: 'SP-1048', supplier: 'Northline Food Supplies', branch: 'Manila Branch', po: 'KN-10482', date: '23 Oct 2026', item: 'Full cream milk · 6 × 1L case', unitPrice: 750, ordered: 50, received: 42, type: 'Short delivery', notes: '8 cases missing from pallet; driver signed receipt noting shortfall.', status: 'Open', evidence: { receipt: true, photo: true, po: true, notes: false }, files: [{ name: 'delivery-receipt.pdf', size: '248 KB' }, { name: 'receiving-count.jpg', size: '1.8 MB' }], timeline: [{ at: '23 Oct 2026 · 08:42', text: 'Case created by Mika Santos' }, { at: '23 Oct 2026 · 08:50', text: '2 evidence files attached' }], recovered: 0 },
  { id: 'SP-1047', supplier: 'FreshRoute Distributors', branch: 'Makati Branch', po: 'KN-10477', date: '22 Oct 2026', item: 'Romaine lettuce · 1 kg pack', unitPrice: 325, ordered: 30, received: 20, type: 'Damaged items', notes: '10 packs wilted and bruised on arrival.', status: 'Awaiting response', evidence: { receipt: true, photo: true, po: true, notes: true }, files: [{ name: 'lettuce-damage.jpg', size: '2.1 MB' }], timeline: [{ at: '22 Oct 2026 · 07:15', text: 'Case created by Mika Santos' }, { at: '22 Oct 2026 · 09:30', text: 'Supplier message sent' }], recovered: 0 },
  { id: 'SP-1046', supplier: 'Island Dairy Co.', branch: 'Quezon City Branch', po: 'KN-10461', date: '19 Oct 2026', item: 'Salted butter · 250 g', unitPrice: 185, ordered: 120, received: 120, type: 'Billing mismatch', notes: 'Invoiced at ₱210/unit vs agreed ₱185/unit.', status: 'Resolved', evidence: { receipt: true, photo: true, po: true, notes: true }, files: [{ name: 'invoice-INV2291.pdf', size: '310 KB' }], timeline: [{ at: '19 Oct 2026 · 10:02', text: 'Case created by Mika Santos' }, { at: '21 Oct 2026 · 14:20', text: 'Supplier issued credit memo · ₱3,000.00 recovered' }, { at: '21 Oct 2026 · 14:21', text: 'Status changed to Resolved' }], recovered: 3000 },
]

/* ---------- primitives ---------- */
const I = {
  grid: 'M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z',
  clip: 'M9 4h6v3H9zM7 5H5v16h14V5h-2M9 12h6M9 16h6',
  gear: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z',
  plus: 'M12 5v14M5 12h14', back: 'M19 12H5M12 19l-7-7 7-7', mail: 'M4 6h16v12H4zM4 7l8 6 8-6', copy: 'M9 9h11v11H9zM5 15H4V4h11v1',
  check: 'M5 12l5 5L20 7', clock: 'M12 7v5l3 2M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z', clipFile: 'M21 11l-8.5 8.5a5 5 0 0 1-7-7L14 4a3.5 3.5 0 0 1 5 5l-8.5 8.5a2 2 0 0 1-3-3L15 7',
  img: 'M4 5h16v14H4zM4 16l5-5 4 4 3-3 4 4M15 9h.01', file: 'M7 3h7l5 5v13H7zM14 3v5h5M10 13h6M10 17h6', search: 'M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM21 21l-5-5', x: 'M6 6l12 12M18 6L6 18',
}
const Icon = ({ d, className = 'size-5' }: { d: string; className?: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden><path d={d} /></svg>
)

function Logo({ size = 'sm' }: { size?: 'sm' | 'lg' }) {
  const big = size === 'lg'
  return (
    <div className="flex items-center gap-2.5">
      <img src={mark} alt="" width={88} height={88} style={{ width: big ? 88 : 32, height: big ? 88 : 32 }} />
      <p className={`font-['Inter:Bold'] font-bold tracking-[-0.02em] ${big ? 'text-[44px]' : 'text-[19px]'}`}>
        <span className="text-ink">Supply</span><span className="text-teal">Proof</span>
      </p>
    </div>
  )
}
function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <label className="flex flex-col gap-1.5 text-sm font-medium text-ink">
      {label}{children}{hint && <span className="text-xs font-normal text-muted">{hint}</span>}
    </label>
  )
}
const ctl = 'h-12 w-full rounded-xl border border-line bg-white px-3.5 text-[15px] text-ink outline-none transition placeholder:text-muted/60 focus:border-teal focus:ring-4 focus:ring-teal/15'
const Input = (p: InputHTMLAttributes<HTMLInputElement>) => <input {...p} className={ctl} />
const Textarea = (p: TextareaHTMLAttributes<HTMLTextAreaElement>) => <textarea {...p} className={`${ctl} h-auto min-h-24 py-3`} />
const Select = ({ children, ...p }: SelectHTMLAttributes<HTMLSelectElement>) => (
  <select {...p} className={`${ctl} appearance-none bg-[url('data:image/svg+xml;utf8,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%2216%22 height=%2216%22 fill=%22none%22 stroke=%22%23203443%22 stroke-width=%222%22><path d=%22M4 6l4 4 4-4%22/></svg>')] bg-[right_14px_center] bg-no-repeat pr-10`}>{children}</select>
)
function Btn({ variant = 'primary', className = '', ...p }: { variant?: 'primary' | 'soft' | 'outline' } & ButtonHTMLAttributes<HTMLButtonElement>) {
  const v = {
    primary: 'bg-teal text-white hover:bg-teal-dark shadow-[0_6px_16px_-6px_rgba(8,126,131,.5)] disabled:opacity-50 disabled:shadow-none',
    soft: 'bg-mint text-teal hover:bg-[#d3ebe7]',
    outline: 'border border-coral bg-white text-ink hover:bg-coral/5',
  }[variant]
  return <button {...p} className={`flex h-12 w-full items-center justify-center gap-2 rounded-2xl text-[15px] font-semibold transition active:scale-[.99] ${v} ${className}`} />
}
const Card = ({ children, className = '' }: { children: ReactNode; className?: string }) => <section className={`rounded-3xl border border-line bg-white p-5 ${className}`}>{children}</section>
function Pill({ s }: { s: Status }) {
  const c = { Open: 'bg-mint text-teal', 'Awaiting response': 'bg-sun/30 text-[#8a5a00]', Resolved: 'bg-ink/8 text-ink', Rejected: 'bg-coral/15 text-[#b4412f]' }[s]
  return <span className={`inline-flex shrink-0 items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold ${c}`}><span className="size-1.5 rounded-full bg-current" />{s}</span>
}
const Row = ({ k, v, strong }: { k: string; v: ReactNode; strong?: boolean }) => (
  <div className="flex justify-between gap-4 py-1.5 text-sm"><span className="text-muted">{k}</span><span className={`text-right ${strong ? 'font-bold' : 'font-medium'}`}>{v}</span></div>
)

/* ---------- auth ---------- */
function Welcome({ go }: { go: (s: Auth) => void }) {
  return (
    <main className="flex min-h-dvh flex-col bg-cream px-6 pb-10">
      <section className="mx-auto flex w-full max-w-md flex-1 flex-col items-center justify-center text-center">
        <img src={mark} alt="" width={88} height={88} className="size-32 drop-shadow-[0_16px_24px_rgba(8,126,131,.25)]" />
        <div className="mx-auto mt-3 h-3 w-20 rounded-full bg-teal/15" />
        <p className="mt-6 font-['Inter:Bold'] text-[40px] font-bold tracking-[-0.02em]"><span className="text-ink">Supply</span><span className="text-teal">Proof</span></p>
        <p className="mt-1 text-muted">Document delivery issues. Recover what’s owed.</p>
      </section>
      <div className="mx-auto flex w-full max-w-md flex-col gap-3">
        <Btn onClick={() => go('signup')}>Get Started</Btn>
        <Btn variant="soft" onClick={() => go('login')}>Log in</Btn>
      </div>
    </main>
  )
}
function AuthShell({ title, sub, children, back }: { title: string; sub: string; children: ReactNode; back: () => void }) {
  return (
    <main className="min-h-dvh bg-cream">
      <header className="border-b border-line bg-white"><div className="mx-auto flex max-w-md items-center justify-between px-6 py-4"><Logo /><button onClick={back} className="text-sm font-medium text-muted hover:text-ink">Back</button></div></header>
      <div className="mx-auto max-w-md px-6 py-8"><h1 className="text-[30px] font-bold tracking-tight">{title}</h1><p className="mt-1 text-muted">{sub}</p><div className="mt-7">{children}</div></div>
    </main>
  )
}
function Login({ go }: { go: (s: Auth) => void }) {
  return (
    <AuthShell title="Welcome back" sub="Document delivery issues. Recover what’s owed." back={() => go('welcome')}>
      <form className="flex flex-col gap-4" onSubmit={(e) => { e.preventDefault(); go('app') }}>
        <Field label="Work email"><Input type="email" defaultValue="mika@kapenorte.example" required /></Field>
        <Field label="Password"><Input type="password" defaultValue="supplyproof24" required /></Field>
        <div className="flex items-center justify-between text-sm">
          <label className="flex items-center gap-2 text-muted"><input type="checkbox" className="size-4 accent-teal" defaultChecked /> Keep me signed in</label>
          <button type="button" className="font-medium text-teal hover:underline">Forgot password?</button>
        </div>
        <Btn className="mt-2">Sign In</Btn>
      </form>
      <p className="mt-8 text-center text-sm text-muted">New to SupplyProof? <button onClick={() => go('signup')} className="font-semibold text-teal hover:underline">Create a workspace</button></p>
    </AuthShell>
  )
}
function Signup({ go }: { go: (s: Auth) => void }) {
  return (
    <AuthShell title="Create your workspace" sub="Set up delivery verification for your business." back={() => go('welcome')}>
      <form className="flex flex-col gap-4" onSubmit={(e) => { e.preventDefault(); go('app') }}>
        <p className="text-xs font-semibold tracking-wider text-teal uppercase">Business</p>
        <Field label="Business name"><Input placeholder="Kape Norte Café" required /></Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Industry type"><Select defaultValue="" required><option value="" disabled>Select</option><option>Restaurant group</option><option>Café / bakery</option><option>Retail chain</option><option>Grocery</option><option>Other</option></Select></Field>
          <Field label="Branches"><Select defaultValue="1–3"><option>1–3</option><option>4–10</option><option>11–25</option><option>26+</option></Select></Field>
        </div>
        <p className="mt-3 text-xs font-semibold tracking-wider text-teal uppercase">Contact</p>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Full name"><Input placeholder="Mika Santos" required /></Field>
          <Field label="Role"><Input placeholder="Operations manager" /></Field>
        </div>
        <Field label="Work email"><Input type="email" placeholder="you@business.example" required /></Field>
        <Field label="Phone number"><Input type="tel" placeholder="+63 917 000 0000" /></Field>
        <Field label="Password"><Input type="password" placeholder="At least 8 characters" minLength={8} required /></Field>
        <label className="mt-1 flex items-start gap-2.5 text-sm text-muted"><input type="checkbox" required className="mt-0.5 size-4 accent-teal" /><span>I agree to SupplyProof’s <a className="font-medium text-teal underline">terms of service</a> and <a className="font-medium text-teal underline">privacy policy</a>.</span></label>
        <Btn className="mt-2">Create Account</Btn>
      </form>
      <p className="mt-8 text-center text-sm text-muted">Already have an account? <button onClick={() => go('login')} className="font-semibold text-teal hover:underline">Sign in</button></p>
    </AuthShell>
  )
}

/* ---------- app screens ---------- */
function CaseCard({ c, open }: { c: Case; open: () => void }) {
  return (
    <button onClick={open} className="w-full rounded-2xl border border-line bg-white p-4 text-left transition hover:border-teal/50 hover:shadow-sm">
      <div className="flex items-start justify-between gap-3"><div><p className="font-bold">{c.id}</p><p className="font-semibold">{c.supplier}</p></div><Pill s={c.status} /></div>
      <p className="mt-2 text-sm text-muted">{c.item}</p>
      <p className="text-sm text-muted">{c.branch} · {c.date}</p>
      <p className="mt-1 text-sm font-medium">{c.type}</p>
      <div className="mt-3 flex justify-between border-t border-line pt-3 text-sm"><span className="text-muted">{c.status === 'Resolved' ? 'Recovered' : 'Est. value'}</span><span className="font-bold">{peso(c.status === 'Resolved' ? c.recovered : value(c))}</span></div>
    </button>
  )
}

function Overview({ cases, nav }: { cases: Case[]; nav: (v: View) => void }) {
  const open = cases.filter((c) => c.status !== 'Resolved' && c.status !== 'Rejected')
  const awaiting = cases.filter((c) => c.status === 'Awaiting response')
  const disputed = open.reduce((s, c) => s + value(c), 0)
  const recovered = cases.reduce((s, c) => s + c.recovered, 0)
  return (
    <div className="flex flex-col gap-4">
      <section className="rounded-3xl bg-mint p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div><h1 className="text-2xl font-bold">Overview</h1><p className="text-sm text-muted">{today()} · Kape Norte Café</p></div>
          <button onClick={() => nav({ name: 'new' })} className="flex items-center gap-1.5 rounded-xl bg-teal px-4 py-2.5 text-sm font-semibold text-white hover:bg-teal-dark"><Icon d={I.plus} className="size-4" />New Discrepancy</button>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-3">
          <div className="rounded-2xl bg-sun p-4"><p className="text-sm font-semibold">Open cases</p><p className="text-3xl font-bold">{open.length}</p><p className="text-xs text-ink/70">Across all branches</p></div>
          <div className="rounded-2xl bg-white p-4"><p className="text-sm font-semibold">Disputed value</p><p className="text-2xl font-bold text-teal sm:text-3xl">{peso(disputed)}</p><p className="text-xs text-muted">Across {open.length} open cases</p></div>
        </div>
      </section>
      <div className="grid grid-cols-2 gap-3">
        <Card className="p-4"><div className="flex items-center gap-2 text-sm font-semibold"><Icon d={I.clock} className="size-4 text-[#c58a00]" />Awaiting supplier response</div><p className="mt-2 text-2xl font-bold">{awaiting.length}</p><p className="text-xs text-muted">Included in open cases</p></Card>
        <Card className="bg-mint/60 p-4"><div className="flex items-center gap-2 text-sm font-semibold"><Icon d={I.check} className="size-4 text-teal" />Recorded recoveries</div><p className="mt-2 text-2xl font-bold">{peso(recovered)}</p><p className="text-xs text-muted">This month · PHP</p></Card>
      </div>
      <div className="mt-2 flex items-center justify-between"><h2 className="text-lg font-bold">Recent discrepancies</h2><button onClick={() => nav({ name: 'list' })} className="text-sm font-semibold text-teal hover:underline">View all discrepancies</button></div>
      <div className="grid gap-3 md:grid-cols-2">{cases.slice(0, 4).map((c) => <CaseCard key={c.id} c={c} open={() => nav({ name: 'case', id: c.id })} />)}</div>
    </div>
  )
}

function List({ cases, nav }: { cases: Case[]; nav: (v: View) => void }) {
  const [filter, setFilter] = useState<'All' | Status>('All')
  const [q, setQ] = useState('')
  const shown = cases.filter((c) => (filter === 'All' || c.status === filter) && `${c.id} ${c.supplier} ${c.po} ${c.item} ${c.branch}`.toLowerCase().includes(q.toLowerCase()))
  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-end justify-between gap-3">
        <div><h1 className="text-2xl font-bold">Discrepancies</h1><p className="text-sm text-muted">{cases.length} cases logged</p></div>
        <button onClick={() => nav({ name: 'new' })} className="flex items-center gap-1.5 rounded-xl bg-teal px-4 py-2.5 text-sm font-semibold text-white hover:bg-teal-dark"><Icon d={I.plus} className="size-4" />New</button>
      </div>
      <div className="relative"><Icon d={I.search} className="absolute top-3.5 left-3.5 size-5 text-muted" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search case, supplier, PO…" className={`${ctl} pl-11`} /></div>
      <div className="-mx-1 flex gap-2 overflow-x-auto px-1 pb-1">
        {(['All', ...STATUSES] as const).map((f) => {
          const n = f === 'All' ? cases.length : cases.filter((c) => c.status === f).length
          return <button key={f} onClick={() => setFilter(f)} className={`shrink-0 rounded-full border px-3.5 py-1.5 text-sm font-medium transition ${filter === f ? 'border-teal bg-teal text-white' : 'border-line bg-white text-ink hover:border-teal/50'}`}>{f} <span className="opacity-70">{n}</span></button>
        })}
      </div>
      {shown.length ? <div className="grid gap-3 md:grid-cols-2">{shown.map((c) => <CaseCard key={c.id} c={c} open={() => nav({ name: 'case', id: c.id })} />)}</div>
        : <Card className="py-10 text-center text-muted">No cases match this filter.</Card>}
    </div>
  )
}

function NewCase({ nextId, onCancel, onCreate }: { nextId: string; onCancel: () => void; onCreate: (c: Case) => void }) {
  const [f, setF] = useState({ supplier: SUPPLIERS[0], branch: BRANCHES[0], po: '', date: new Date().toISOString().slice(0, 10), item: '', unitPrice: '', ordered: '', received: '', type: ISSUES[0], notes: '' })
  const [files, setFiles] = useState<{ name: string; size: string; kind: 'receipt' | 'photo' }[]>([])
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value })
  const short = Math.max(0, Number(f.ordered || 0) - Number(f.received || 0))
  const est = short * Number(f.unitPrice || 0)
  const add = (kind: 'receipt' | 'photo') => (e: React.ChangeEvent<HTMLInputElement>) => {
    const list = Array.from(e.target.files ?? []).map((x) => ({ name: x.name, kind, size: x.size > 1e6 ? (x.size / 1e6).toFixed(1) + ' MB' : Math.round(x.size / 1e3) + ' KB' }))
    setFiles((p) => [...p, ...list]); e.target.value = ''
  }
  const hasReceipt = files.some((x) => x.kind === 'receipt'), hasPhoto = files.some((x) => x.kind === 'photo')
  const valid = f.po && f.item && f.unitPrice && f.ordered && f.received
  const submit = () => {
    if (!valid) return
    const d = new Date(f.date).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })
    const now = `${today()} · ${new Date().toTimeString().slice(0, 5)}`
    onCreate({
      id: nextId, supplier: f.supplier, branch: f.branch, po: f.po, date: d, item: f.item, unitPrice: Number(f.unitPrice), ordered: Number(f.ordered), received: Number(f.received), type: f.type, notes: f.notes,
      status: 'Open', evidence: { receipt: hasReceipt, photo: hasPhoto, po: !!f.po, notes: !!f.notes.trim() }, files: files.map(({ name, size }) => ({ name, size })),
      timeline: [{ at: now, text: 'Case created by Mika Santos' }, ...(files.length ? [{ at: now, text: `${files.length} evidence file${files.length > 1 ? 's' : ''} attached` }] : [])], recovered: 0,
    })
  }
  const upload = (kind: 'receipt' | 'photo', label: string, icon: string, dashed?: boolean) => (
    <label className={`flex cursor-pointer items-center gap-3 rounded-2xl border bg-mint px-4 py-3.5 font-medium transition hover:bg-[#d3ebe7] ${dashed ? 'border-dashed border-teal/40' : 'border-line'}`}>
      <Icon d={icon} className="size-5 text-muted" />{label}
      <input type="file" multiple accept={kind === 'photo' ? 'image/*' : 'image/*,.pdf'} className="sr-only" onChange={add(kind)} />
    </label>
  )
  return (
    <div className="flex flex-col gap-4 pb-24">
      <section className="rounded-3xl bg-teal p-6 text-white"><h1 className="text-2xl font-bold sm:text-3xl">New discrepancy</h1><p className="mt-1 text-white/85">Record a delivery issue and prepare evidence for the supplier.</p></section>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <h2 className="text-lg font-bold">Delivery details</h2>
          <div className="mt-4 flex flex-col gap-4">
            <Field label="Supplier"><Select value={f.supplier} onChange={set('supplier')}>{SUPPLIERS.map((s) => <option key={s}>{s}</option>)}</Select></Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Branch"><Select value={f.branch} onChange={set('branch')}>{BRANCHES.map((s) => <option key={s}>{s}</option>)}</Select></Field>
              <Field label="Delivery date"><Input type="date" value={f.date} onChange={set('date')} /></Field>
            </div>
            <Field label="PO reference"><Input value={f.po} onChange={set('po')} placeholder="e.g. KN-10490" /></Field>
            <Field label="Item"><Input value={f.item} onChange={set('item')} placeholder="e.g. Full cream milk · 6 × 1L case" /></Field>
            <Field label="Issue type"><Select value={f.type} onChange={set('type')}>{ISSUES.map((s) => <option key={s}>{s}</option>)}</Select></Field>
          </div>
        </Card>
        <Card>
          <h2 className="text-lg font-bold">Quantity comparison</h2>
          <div className="mt-4 grid grid-cols-3 gap-3">
            <Field label="Ordered"><Input type="number" min={0} value={f.ordered} onChange={set('ordered')} placeholder="50" /></Field>
            <Field label="Received"><Input type="number" min={0} value={f.received} onChange={set('received')} placeholder="42" /></Field>
            <Field label="Unit price ₱"><Input type="number" min={0} value={f.unitPrice} onChange={set('unitPrice')} placeholder="750" /></Field>
          </div>
          <div className="mt-4 rounded-2xl bg-cream px-4 py-3"><Row k="Shortfall" v={<span className={short ? 'text-[#c25e00]' : ''}>{short} units</span>} strong /></div>
          <div className="mt-4"><Field label="Notes"><Textarea value={f.notes} onChange={set('notes')} placeholder="What happened? Who received the delivery? Any driver remarks?" /></Field></div>
        </Card>
        <Card>
          <div className="flex items-center gap-3"><h2 className="text-lg font-bold">Attach Photo Evidence</h2><span className="rounded-full bg-coral px-2.5 py-0.5 text-xs font-semibold text-ink">Required</span></div>
          <p className="mt-2 text-sm text-muted">Required: signed delivery receipt and a clear photo of the received boxes.</p>
          <p className="mt-4 mb-2 text-sm font-semibold text-muted">Attach files</p>
          {upload('receipt', '+ Upload Delivery Receipt', I.clipFile)}
          <p className="mt-4 mb-2 text-sm font-semibold text-muted">Photo of delivered boxes</p>
          {upload('photo', '+ Add Photo of Delivered Boxes', I.img, true)}
          {files.length > 0 && <ul className="mt-3 flex flex-col gap-2">{files.map((x, i) => (
            <li key={i} className="flex items-center gap-3 rounded-2xl border border-line bg-mint px-4 py-3 text-sm">
              <Icon d={x.kind === 'photo' ? I.img : I.file} className="size-5 text-muted" /><span className="flex-1 truncate font-medium">{x.name}</span><span className="font-semibold text-muted">{x.size}</span>
              <button onClick={() => setFiles(files.filter((_, j) => j !== i))} className="text-muted hover:text-ink" aria-label="Remove"><Icon d={I.x} className="size-4" /></button>
            </li>))}</ul>}
        </Card>
        <section className="h-fit rounded-3xl border border-line bg-mint p-5">
          <p className="text-sm font-semibold text-muted">Estimate</p>
          <div className="mt-2 flex items-center justify-between"><span>Discrepancy value</span><span className="text-2xl font-bold">{peso(est)}</span></div>
          <p className="mt-1 text-xs text-muted">{short} × {peso(Number(f.unitPrice || 0))} · Excluding VAT</p>
          {!valid && <p className="mt-3 text-xs text-[#b4412f]">Fill in PO reference, item, quantities, and unit price to create the case.</p>}
        </section>
      </div>
      <div className="fixed inset-x-0 bottom-[68px] z-10 border-t border-line bg-white">
        <div className="mx-auto flex max-w-5xl gap-3 px-5 py-3"><Btn variant="outline" onClick={onCancel}>Cancel</Btn><Btn onClick={submit} disabled={!valid}>Create Case</Btn></div>
      </div>
    </div>
  )
}

function CaseView({ c, update, nav }: { c: Case; update: (c: Case) => void; nav: (v: View) => void }) {
  const [sheet, setSheet] = useState(false)
  const [status, setStatus] = useState<Status>(c.status)
  const [response, setResponse] = useState('')
  const [rec, setRec] = useState('')
  const stamp = () => `${today()} · ${new Date().toTimeString().slice(0, 5)}`
  const short = c.ordered - c.received
  const checks: [keyof Evidence, string][] = [['receipt', 'Signed delivery receipt'], ['photo', 'Photo of delivered goods'], ['po', 'PO reference matched'], ['notes', 'Receiving notes recorded']]
  const toggle = (k: keyof Evidence) => update({ ...c, evidence: { ...c.evidence, [k]: !c.evidence[k] } })
  const save = () => {
    const events: { at: string; text: string }[] = []
    if (response.trim()) events.push({ at: stamp(), text: `Supplier response: “${response.trim()}”` })
    if (Number(rec) > 0) events.push({ at: stamp(), text: `${peso(Number(rec))} recovered` })
    if (status !== c.status) events.push({ at: stamp(), text: `Status changed to ${status}` })
    update({ ...c, status, recovered: c.recovered + Number(rec || 0), timeline: [...c.timeline, ...events] })
    setSheet(false); setResponse(''); setRec('')
  }
  return (
    <div className="flex flex-col gap-4 pb-40">
      <button onClick={() => nav({ name: 'list' })} className="flex w-fit items-center gap-1.5 text-sm font-semibold text-teal"><Icon d={I.back} className="size-4" />All discrepancies</button>
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="flex flex-col gap-4">
          <Card>
            <p className="text-xs font-semibold tracking-wider text-muted uppercase">Case {c.id}</p>
            <div className="mt-1 flex items-start justify-between gap-3"><h1 className="text-xl font-bold">{c.type} · {c.supplier}</h1><Pill s={c.status} /></div>
            <p className="mt-2 text-sm text-muted">{c.item} · {c.branch}</p>
            <div className="mt-3 divide-y divide-line/60"><Row k="Supplier" v={c.supplier} /><Row k="Branch" v={c.branch} /><Row k="PO reference" v={c.po} /><Row k="Delivery date" v={c.date} /></div>
            <div className="mt-4 rounded-2xl bg-mint p-4">
              <p className="text-xs font-semibold text-muted">Estimated amount affected</p>
              <p className="text-3xl font-bold">{peso(value(c))}</p>
              <p className="mt-1 text-xs text-muted">{short} × {peso(c.unitPrice)} · Excluding VAT · {c.recovered ? `${peso(c.recovered)} recovered` : 'Not yet recovered'}</p>
            </div>
          </Card>
          <Card>
            <h2 className="text-lg font-bold">Quantity comparison</h2>
            <div className="mt-2"><Row k="Ordered" v={c.ordered} strong /><Row k="Received" v={c.received} strong /><Row k="Shortfall" v={<span className="text-[#c25e00]">{short}</span>} strong /></div>
            {c.notes && <p className="mt-3 rounded-2xl bg-cream p-3 text-sm">{c.notes}</p>}
          </Card>
        </div>
        <div className="flex flex-col gap-4">
          <Card>
            <div className="flex items-center justify-between"><h2 className="text-lg font-bold">Evidence checklist</h2>
              <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${ready(c.evidence) ? 'bg-mint text-teal' : 'bg-sun/30 text-[#8a5a00]'}`}>{ready(c.evidence) ? 'Ready for supplier' : `${Object.values(c.evidence).filter(Boolean).length}/4 complete`}</span></div>
            <ul className="mt-3 flex flex-col gap-2">{checks.map(([k, label]) => (
              <li key={k}><button onClick={() => toggle(k)} className="flex w-full items-center gap-3 rounded-xl px-1 py-1.5 text-left text-sm hover:bg-mint/50">
                <span className={`grid size-6 place-items-center rounded-lg border ${c.evidence[k] ? 'border-teal bg-teal text-white' : 'border-line bg-white'}`}>{c.evidence[k] && <Icon d={I.check} className="size-4" />}</span>{label}</button></li>))}</ul>
            {c.files.length > 0 && <ul className="mt-3 flex flex-col gap-2">{c.files.map((x) => (
              <li key={x.name} className="flex items-center gap-3 rounded-xl border border-line bg-mint px-3 py-2.5 text-sm"><Icon d={/\.(jpe?g|png|heic|webp)$/i.test(x.name) ? I.img : I.file} className="size-4 text-muted" /><span className="flex-1 truncate">{x.name}</span><span className="text-muted">{x.size}</span></li>))}</ul>}
          </Card>
          <Card>
            <h2 className="text-lg font-bold">Timeline</h2>
            <ol className="mt-3 flex flex-col">{c.timeline.map((t, i) => (
              <li key={i} className="relative flex gap-3 pb-4 last:pb-0">
                {i < c.timeline.length - 1 && <span className="absolute top-4 left-[5px] h-full w-px bg-line" />}
                <span className={`relative mt-1.5 size-[11px] shrink-0 rounded-full ${i === c.timeline.length - 1 ? 'bg-teal' : 'bg-line'}`} />
                <div><p className="text-sm font-medium">{t.text}</p><p className="text-xs text-muted">{t.at}</p></div>
              </li>))}</ol>
          </Card>
        </div>
      </div>
      <div className="fixed inset-x-0 bottom-[68px] z-10 border-t border-line bg-white">
        <div className="mx-auto grid max-w-5xl gap-2 px-5 py-3 sm:grid-cols-2">
          <Btn onClick={() => nav({ name: 'message', id: c.id })}><Icon d={I.mail} />Generate Supplier Message</Btn>
          <Btn variant="outline" onClick={() => { setStatus(c.status); setSheet(true) }}><Icon d={I.clip} />Update Status</Btn>
        </div>
      </div>
      {sheet && (
        <div className="fixed inset-0 z-30 flex items-end justify-center bg-ink/40 sm:items-center" onClick={() => setSheet(false)}>
          <div className="w-full max-w-md rounded-t-3xl bg-white p-6 sm:rounded-3xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between"><h2 className="text-xl font-bold">Update status</h2><button onClick={() => setSheet(false)} aria-label="Close"><Icon d={I.x} /></button></div>
            <div className="mt-4 flex flex-col gap-4">
              <Field label="Case status"><div className="grid grid-cols-2 gap-2">{STATUSES.map((s) => (
                <button key={s} type="button" onClick={() => setStatus(s)} className={`rounded-xl border px-3 py-2.5 text-sm font-medium ${status === s ? 'border-teal bg-mint text-teal' : 'border-line'}`}>{s}</button>))}</div></Field>
              <Field label="Supplier response (optional)"><Textarea value={response} onChange={(e) => setResponse(e.target.value)} placeholder="e.g. Northline confirmed shortfall, credit memo to follow." /></Field>
              <Field label="Amount recovered ₱ (optional)"><Input type="number" min={0} value={rec} onChange={(e) => setRec(e.target.value)} placeholder="0.00" /></Field>
              <Btn onClick={save}>Save Update</Btn>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function Message({ c, update, nav }: { c: Case; update: (c: Case) => void; nav: (v: View) => void }) {
  const [copied, setCopied] = useState(false)
  const short = c.ordered - c.received
  const sent = c.timeline.some((t) => t.text === 'Supplier message sent')
  const team = c.supplier.split(' ')[0]
  const body = `Good day, ${team} team,

We would like to formally raise a delivery discrepancy under PO ${c.po}, received on ${c.date} at our ${c.branch}.

Item: ${c.item}
Ordered: ${c.ordered}
Received: ${c.received}
Shortfall: ${short}
${short} × ${peso(c.unitPrice)} = ${peso(value(c))} PHP

Issue: ${c.type}${c.notes ? `\nNotes: ${c.notes}` : ''}

Supporting evidence (${c.files.length} file${c.files.length === 1 ? '' : 's'}) is attached. Kindly confirm and advise on a credit memo or replacement delivery.

Thank you,
Mika Santos
Operations Manager, Kape Norte Café`
  const copy = async () => {
    try { await navigator.clipboard.writeText(body) } catch { /* clipboard unavailable in some previews */ }
    setCopied(true); setTimeout(() => setCopied(false), 2000)
    if (!sent) update({ ...c, status: c.status === 'Open' ? 'Awaiting response' : c.status, timeline: [...c.timeline, { at: `${today()} · ${new Date().toTimeString().slice(0, 5)}`, text: 'Supplier message sent' }] })
  }
  return (
    <div className="flex flex-col gap-4 pb-40">
      <div><p className="text-xs font-semibold tracking-wider text-muted uppercase">Case {c.id}</p><h1 className="text-2xl font-bold">Supplier message</h1><p className="text-sm text-muted">A clear summary of the delivery issue, ready to share with your supplier.</p></div>
      <Card>
        <div className="flex items-center justify-between"><div className="flex items-center gap-2 font-bold"><Icon d={I.mail} className="size-5 text-teal" />Message preview</div>
          <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${sent ? 'bg-mint text-teal' : 'bg-sun/30 text-[#8a5a00]'}`}>{sent ? 'Sent' : 'Not sent'}</span></div>
        <div className="mt-3 border-b border-line pb-3"><Row k="Supplier" v={c.supplier} /><Row k="Subject" v={`Delivery ${c.type.toLowerCase()} — PO ${c.po} — Case ${c.id}`} strong /></div>
        <pre className="mt-4 font-sans text-sm leading-relaxed whitespace-pre-wrap">{body}</pre>
        {!ready(c.evidence) && <p className="mt-4 rounded-xl bg-sun/25 p-3 text-sm">Evidence checklist is incomplete. Consider completing it before contacting the supplier.</p>}
      </Card>
      <div className="fixed inset-x-0 bottom-[68px] z-10 border-t border-line bg-white">
        <div className="mx-auto grid max-w-5xl gap-2 px-5 py-3 sm:grid-cols-2">
          <Btn onClick={copy}><Icon d={copied ? I.check : I.copy} />{copied ? 'Copied to clipboard' : 'Copy Message'}</Btn>
          <Btn variant="outline" onClick={() => nav({ name: 'case', id: c.id })}><Icon d={I.back} />Back to Case</Btn>
        </div>
      </div>
    </div>
  )
}

function Settings({ signOut }: { signOut: () => void }) {
  const [saved, setSaved] = useState(false)
  return (
    <form className="flex flex-col gap-4 pb-40" onSubmit={(e) => { e.preventDefault(); setSaved(true); setTimeout(() => setSaved(false), 2200) }}>
      <h1 className="text-2xl font-bold">Settings</h1>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="h-fit">
          <h2 className="font-bold">Workspace & contact</h2>
          <ul className="mt-3 flex flex-col gap-2 text-sm"><li className="flex items-center gap-2"><span className="size-2 rounded-full bg-teal" />Sample workspace · 3 branches · Philippines</li><li className="flex items-center gap-2"><span className="size-2 rounded-full bg-teal" />Mika Santos · Operations manager</li></ul>
          <button type="button" onClick={signOut} className="mt-5 text-sm font-semibold text-[#b4412f] hover:underline">Sign out</button>
        </Card>
        <Card>
          <h2 className="font-bold">Business details</h2>
          <div className="mt-4 flex flex-col gap-4">
            <Field label="Business name"><Input defaultValue="Kape Norte Café" /></Field>
            <Field label="Industry type"><Select defaultValue="Café / bakery"><option>Restaurant group</option><option>Café / bakery</option><option>Retail chain</option><option>Grocery</option></Select></Field>
            <Field label="Default branch"><Select defaultValue={BRANCHES[0]}>{BRANCHES.map((b) => <option key={b}>{b}</option>)}</Select></Field>
            <Field label="Contact email"><Input type="email" defaultValue="mika@kapenorte.example" /></Field>
            <Field label="Contact phone"><Input type="tel" defaultValue="+63 917 555 0148" /></Field>
            <Field label="Preferred currency"><Select defaultValue="PHP"><option value="PHP">PHP — Philippine peso (₱)</option><option value="USD">USD — US dollar ($)</option></Select></Field>
            <div className="rounded-2xl bg-mint p-4 text-sm"><p className="font-semibold">Defaults explanation</p><p className="mt-1 text-muted">The default branch and currency pre-fill every new discrepancy and supplier message.</p></div>
          </div>
        </Card>
      </div>
      <div className="fixed inset-x-0 bottom-[68px] z-10 border-t border-line bg-white"><div className="mx-auto max-w-5xl px-5 py-3"><Btn>{saved ? <><Icon d={I.check} />Changes saved</> : 'Save Changes'}</Btn></div></div>
    </form>
  )
}

function Shell({ signOut }: { signOut: () => void }) {
  const [cases, setCases] = useState<Case[]>(SEED)
  const [view, setView] = useState<View>({ name: 'overview' })
  const nav = (v: View) => { setView(v); window.scrollTo(0, 0) }
  const update = (c: Case) => setCases((p) => p.map((x) => (x.id === c.id ? c : x)))
  const nextId = useMemo(() => 'SP-' + (Math.max(...cases.map((c) => Number(c.id.slice(3)))) + 1), [cases])
  const tab: Tab = view.name === 'overview' ? 'overview' : view.name === 'settings' ? 'settings' : 'list'
  const current = 'id' in view ? cases.find((c) => c.id === view.id) : undefined
  const tabs: [Tab, string, string][] = [['overview', 'Overview', I.grid], ['list', 'Discrepancies', I.clip], ['settings', 'Settings', I.gear]]
  return (
    <main className="min-h-dvh bg-cream pb-[68px]">
      <header className="sticky top-0 z-20 border-b border-line bg-white">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-5 py-3">
          <button onClick={() => nav({ name: 'overview' })} className="text-left"><Logo /><p className="mt-0.5 text-sm text-muted">Kape Norte Café</p></button>
          <div className="flex gap-2">
            <span className="grid size-11 place-items-center rounded-2xl bg-mint text-sm font-semibold">MS</span>
            <button onClick={() => nav({ name: 'settings' })} className="grid size-11 place-items-center rounded-2xl border border-line hover:bg-mint" aria-label="Settings"><Icon d={I.gear} /></button>
          </div>
        </div>
      </header>
      <div className="mx-auto max-w-5xl px-5 py-5">
        {view.name === 'overview' && <Overview cases={cases} nav={nav} />}
        {view.name === 'list' && <List cases={cases} nav={nav} />}
        {view.name === 'settings' && <Settings signOut={signOut} />}
        {view.name === 'new' && <NewCase nextId={nextId} onCancel={() => nav({ name: 'overview' })} onCreate={(c) => { setCases((p) => [c, ...p]); nav({ name: 'case', id: c.id }) }} />}
        {view.name === 'case' && current && <CaseView key={current.id} c={current} update={update} nav={nav} />}
        {view.name === 'message' && current && <Message c={current} update={update} nav={nav} />}
      </div>
      <nav className="fixed inset-x-0 bottom-0 z-20 h-[68px] border-t border-line bg-white">
        <div className="mx-auto grid h-full max-w-5xl grid-cols-3">
          {tabs.map(([t, label, d]) => (
            <button key={t} onClick={() => nav({ name: t } as View)} className={`flex flex-col items-center justify-center gap-0.5 text-sm ${tab === t ? 'font-semibold text-teal' : 'text-muted hover:text-ink'}`}><Icon d={d} />{label}</button>
          ))}
        </div>
      </nav>
    </main>
  )
}

export default function App() {
  const [screen, setScreen] = useState<Auth>('welcome')
  const go = (s: Auth) => { setScreen(s); window.scrollTo(0, 0) }
  if (screen === 'login') return <Login go={go} />
  if (screen === 'signup') return <Signup go={go} />
  if (screen === 'app') return <Shell signOut={() => go('welcome')} />
  return <Welcome go={go} />
}
